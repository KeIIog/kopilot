#!/usr/bin/env python3
from pathlib import Path
import shutil, sys, json, time

VERSION = 'kopilot-2026.09.25-v0.1'
REPLACEMENTS = [('selfdrive/controls/lib/longitudinal_mpc_lib/long_mpc.py', 'def get_T_FOLLOW(personality=log.LongitudinalPersonality.standard):\n  if personality==log.LongitudinalPersonality.relaxed:\n    return 1.75\n  elif personality==log.LongitudinalPersonality.standard:\n    return 1.45\n  elif personality==log.LongitudinalPersonality.aggressive:\n    return 1.25\n', 'def get_T_FOLLOW(personality=log.LongitudinalPersonality.standard):\n  # KOPILOT: slightly earlier lead response without changing emergency limits.\n  if personality==log.LongitudinalPersonality.relaxed:\n    return 1.85\n  elif personality==log.LongitudinalPersonality.standard:\n    return 1.55\n  elif personality==log.LongitudinalPersonality.aggressive:\n    return 1.25\n', 'following-time margin'), ('selfdrive/controls/lib/longitudinal_planner.py', '    for idx in range(2):\n      accel_clip[idx] = np.clip(accel_clip[idx], self.prev_accel_clip[idx] - 0.05, self.prev_accel_clip[idx] + 0.05)\n    self.output_a_target = np.clip(output_a_target, accel_clip[0], accel_clip[1])\n    self.prev_accel_clip = accel_clip\n', '    for idx in range(2):\n      accel_clip[idx] = np.clip(accel_clip[idx], self.prev_accel_clip[idx] - 0.05, self.prev_accel_clip[idx] + 0.05)\n\n    clipped_output_a_target = float(np.clip(output_a_target, accel_clip[0], accel_clip[1]))\n\n    # KOPILOT: smooth positive acceleration only.\n    # Do not rate-limit deceleration here: lead braking / stop / FCW authority must remain immediate.\n    if not reset_state and not self.output_should_stop and clipped_output_a_target > self.output_a_target:\n      max_accel_rise = 0.80 * self.dt\n      clipped_output_a_target = min(clipped_output_a_target, self.output_a_target + max_accel_rise)\n\n    self.output_a_target = clipped_output_a_target\n    self.prev_accel_clip = accel_clip\n', 'positive-acceleration smoothing'), ('system/manager/process_config.py', 'def driverview(started: bool, params: Params, CP: car.CarParams) -> bool:\n  return started or params.get_bool("IsDriverViewEnabled")\n', 'def driverview(started: bool, params: Params, CP: car.CarParams) -> bool:\n  # KOPILOT Pet/Remote monitor is camera-only. It does not command HVAC, ignition, steering or braking.\n  return (started\n          or params.get_bool("IsDriverViewEnabled")\n          or params.get_bool("KopilotPetMode")\n          or params.get_bool("KopilotRemoteMonitor"))\n', 'Pet/remote camera lifecycle'), ('system/manager/process_config.py', '  PythonProcess("webrtcd", "system.webrtc.webrtcd", notcar),\n  PythonProcess("webjoystick", "tools.bodyteleop.web", notcar),\n', '  PythonProcess("webrtcd", "system.webrtc.webrtcd", notcar),\n  # KOPILOT read-only road/driver camera monitor. Incoming cereal control is disabled in carrot_webrtcd.py.\n  PythonProcess("carrot_webrtcd", "system.webrtc.carrot_webrtcd", driverview, enabled=not PC),\n  PythonProcess("webjoystick", "tools.bodyteleop.web", notcar),\n', 'read-only WebRTC manager process')]
PAYLOADS = ['system/webrtc/carrot_webrtcd.py', 'tools/kopilot/config.py', 'tools/kopilot/validate_patch.py', 'tools/kopilot/check_carrot_upstream.py', '.github/workflows/kopilot-upstream-watch.yml', 'KOPILOT_UPSTREAM.json']

repo = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
pkg = Path(__file__).resolve().parent
backup_root = repo / ".kopilot_patch_backup" / VERSION

if not (repo / ".git").exists():
  raise SystemExit(f"Not a git repo: {repo}")

def backup(rel):
  src = repo / rel
  dst = backup_root / rel
  if dst.exists():
    return
  dst.parent.mkdir(parents=True, exist_ok=True)
  shutil.copy2(src, dst)

for path, old, new, label in REPLACEMENTS:
  p = repo / path
  text = p.read_text(encoding="utf-8")
  if new in text:
    print("SKIP already patched:", label)
    continue
  if old not in text:
    raise RuntimeError(f"Expected source block not found for {label}: {path}")
  backup(path)
  p.write_text(text.replace(old, new, 1), encoding="utf-8")
  print("PATCH:", label)

for rel in PAYLOADS:
  src = pkg / "payload" / rel
  dst = repo / rel
  if dst.exists():
    backup(rel)
  dst.parent.mkdir(parents=True, exist_ok=True)
  shutil.copy2(src, dst)
  print("INSTALL:", rel)

(repo / ".kopilot_patch_state.json").write_text(json.dumps({
  "version": VERSION,
  "applied_at_unix": int(time.time()),
  "backup": str(backup_root),
}, indent=2), encoding="utf-8")

print("\nApplied", VERSION)
print("Run: python tools/kopilot/validate_patch.py")
print("Then: git diff --check && git diff")

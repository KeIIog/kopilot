@echo off
python "%~dp0apply_patch.py" "%CD%"

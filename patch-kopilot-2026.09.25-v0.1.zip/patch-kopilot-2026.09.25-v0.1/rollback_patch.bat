@echo off
python "%~dp0rollback_patch.py" "%CD%"

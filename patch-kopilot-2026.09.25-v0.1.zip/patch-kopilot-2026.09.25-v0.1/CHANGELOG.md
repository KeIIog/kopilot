# CHANGELOG

- v0.1: conservative longitudinal + read-only WebRTC + monitor-only Pet Mode + daily upstream watch.

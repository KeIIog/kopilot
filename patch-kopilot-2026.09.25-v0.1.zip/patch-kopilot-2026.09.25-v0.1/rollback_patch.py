#!/usr/bin/env python3
from pathlib import Path
import shutil, sys

VERSION = 'kopilot-2026.09.25-v0.1'
repo = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
backup = repo / ".kopilot_patch_backup" / VERSION

if not backup.exists():
  raise SystemExit("Backup not found: " + str(backup))

for src in backup.rglob("*"):
  if src.is_file():
    rel = src.relative_to(backup)
    dst = repo / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    print("RESTORE:", rel)

introduced = ['tools/kopilot/config.py', 'tools/kopilot/validate_patch.py', 'tools/kopilot/check_carrot_upstream.py', '.github/workflows/kopilot-upstream-watch.yml', 'KOPILOT_UPSTREAM.json']

for rel in introduced:
  p = repo / rel
  if p.exists() and not (backup / rel).exists():
    p.unlink()
    print("REMOVE:", rel)

state = repo / ".kopilot_patch_state.json"
if state.exists():
  state.unlink()
print("Rollback complete:", VERSION)

# Kopilot patch 2026.09.25 v0.1

대상: `KeIIog/kopilot` / `feature/kopilot-2026-integration`

### 변경
- Relaxed T_FOLLOW 1.75 → 1.85 s
- Standard T_FOLLOW 1.45 → 1.55 s
- 급가속 방향만 0.80 m/s³ 상당으로 완화
- 감속/제동 방향은 rate-limit 하지 않음
- 깨져 있던 `carrot_webrtcd.py` wrapper 수정
- road/driver/wideRoad 카메라만 허용, incoming cereal bridge 차단(읽기 전용)
- 토큰 없으면 localhost만, 토큰 있으면 0.0.0.0:5001 + Bearer 인증
- Monitor-only Pet Mode lifecycle 추가(HVAC/시동/CAN 제어 없음)
- 매일 Carrot `carrot-wip` 확인 workflow 추가(자동 merge 없음)
- rollback/validation 포함

### 적용
```bat
cd /d D:\kopilot
python <압축푼폴더>\apply_patch.py .
python tools\kopilot\validate_patch.py
git diff --check
git diff
```

### Remote/Pet
```bash
python tools/kopilot/config.py token
python tools/kopilot/config.py remote-on
python tools/kopilot/config.py pet-on
python tools/kopilot/config.py status
```

### 끄기
```bash
python tools/kopilot/config.py pet-off
python tools/kopilot/config.py remote-off
```

### Rollback
```bat
python rollback_patch.py .
```

주의: 실차 도로 검증 완료본이 아니다. Panda/CAN safety 우회는 포함하지 않았다.
최신 Carrot dPath/radar_motion 전체 이식과 lateral gain 변경은 호환/리플레이 검증 전이라 v0.1에서 보류했다.
